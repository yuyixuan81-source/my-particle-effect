import React, { useRef, useState, useEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import { Color, Mesh } from 'three';
import { Text } from '@react-three/drei';
import { audioService } from '../services/audioService';

interface PianoProps {
  handPositions: { x: number; y: number }[];
  onKeyPress: (note: string) => void;
}

export const PIANO_WIDTH = 20; // Increased interactive width to accommodate more keys

// Helper to generate notes for 2 octaves (C3 to B4)
const generateNotes = () => {
    const keys = [];
    const startOctave = 3;
    const numOctaves = 2; 
    const whiteKeyWidth = 1.0; 
    const numWhiteKeys = numOctaves * 7;
    // Center the piano: Shift so the middle of the key set is at x=0
    // Total width of white keys is (numWhiteKeys * 1).
    // range 0 to 14. Center is 7. Shift by -6.5 to center the keys (0..13) -> (-6.5..6.5)
    const startX = -((numWhiteKeys - 1) * whiteKeyWidth) / 2;
    
    const octavePattern = [
        { note: 'C', type: 'white', offset: 0 },
        { note: 'C#', type: 'black', offset: 0.5 },
        { note: 'D', type: 'white', offset: 1 },
        { note: 'D#', type: 'black', offset: 1.5 },
        { note: 'E', type: 'white', offset: 2 },
        { note: 'F', type: 'white', offset: 3 },
        { note: 'F#', type: 'black', offset: 3.5 },
        { note: 'G', type: 'white', offset: 4 },
        { note: 'G#', type: 'black', offset: 4.5 },
        { note: 'A', type: 'white', offset: 5 },
        { note: 'A#', type: 'black', offset: 5.5 },
        { note: 'B', type: 'white', offset: 6 },
    ];

    const baseColors: any = { 
        'C': '#ff0000', 'C#': '#ff4400', 
        'D': '#ff8800', 'D#': '#ffcc00', 
        'E': '#ffff00', 
        'F': '#ccff00', 'F#': '#88ff00', 
        'G': '#44ff00', 'G#': '#00ff44', 
        'A': '#00ff88', 'A#': '#00ffcc', 
        'B': '#00ffff' 
    };

    const getFreq = (note: string, octave: number) => {
        const noteMap: any = { 'C': -9, 'C#': -8, 'D': -7, 'D#': -6, 'E': -5, 'F': -4, 'F#': -3, 'G': -2, 'G#': -1, 'A': 0, 'A#': 1, 'B': 2 };
        const semitone = noteMap[note] + (octave - 4) * 12; // Relative to A4 (440Hz)
        return 440 * Math.pow(2, semitone / 12);
    };

    for (let o = 0; o < numOctaves; o++) {
        const oct = startOctave + o;
        const octaveX = o * 7 * whiteKeyWidth;

        octavePattern.forEach(k => {
            const x = startX + octaveX + k.offset;
            keys.push({
                name: `${k.note}${oct}`,
                freq: getFreq(k.note, oct),
                color: baseColors[k.note],
                x: x,
                type: k.type
            });
        });
    }
    return keys;
};

export const NOTES = generateNotes();

const Key = ({ name, x, type, color, isPressed }: any) => {
  const mesh = useRef<Mesh>(null);
  
  useFrame(() => {
    if (mesh.current) {
      // Animate press
      const targetY = isPressed ? -0.2 : 0;
      mesh.current.position.y += (targetY - mesh.current.position.y) * 0.2;
      
      // Glow effect when pressed
      if (isPressed && mesh.current.material) {
        (mesh.current.material as any).emissive.set(color);
        (mesh.current.material as any).emissiveIntensity = 2;
      } else if (mesh.current.material) {
        (mesh.current.material as any).emissive.set('#000000');
        (mesh.current.material as any).emissiveIntensity = 0;
      }
    }
  });

  const height = type === 'white' ? 4 : 2.5;
  const width = type === 'white' ? 0.9 : 0.6;
  const z = type === 'white' ? 0 : -0.75;
  const y = type === 'black' ? 0.2 : 0;
  
  return (
    <group position={[x, y, z]}>
      <mesh ref={mesh}>
        <boxGeometry args={[width, 0.5, height]} />
        <meshStandardMaterial 
          color={type === 'white' ? '#eeeeee' : '#111111'} 
          roughness={0.1}
          metalness={0.3}
        />
      </mesh>
      {/* Show note name only on C keys to avoid clutter */}
      {name && name.startsWith('C') && !name.includes('#') && (
        <Text position={[0, 0.3, 1.5]} fontSize={0.3} color="gray" rotation={[-Math.PI / 2, 0, 0]}>
          {name}
        </Text>
      )}
    </group>
  );
};

export const Piano: React.FC<PianoProps> = ({ handPositions, onKeyPress }) => {
  const [activeKeys, setActiveKeys] = useState<Record<string, boolean>>({});
  const lastPressTime = useRef<Record<string, number>>({});

  useFrame(() => {
    const newActiveKeys: Record<string, boolean> = {};
    const currentTime = Date.now();

    handPositions.forEach(hand => {
      // Map screen coords (0-1) to world coords using PIANO_WIDTH
      const worldX = (hand.x - 0.5) * PIANO_WIDTH; 
      
      NOTES.forEach(key => {
        // Simple 1D collision detection for x-axis
        const hitWidth = key.type === 'white' ? 0.45 : 0.3;
        if (Math.abs(worldX - key.x) < hitWidth) {
           // Debounce
           if (!activeKeys[key.name] && (currentTime - (lastPressTime.current[key.name] || 0) > 200)) {
             audioService.playNote(key.freq);
             onKeyPress(key.name);
             lastPressTime.current[key.name] = currentTime;
           }
           newActiveKeys[key.name] = true;
        }
      });
    });

    // Also keep keys active for a short duration visually even if hand moves
    NOTES.forEach(key => {
        if (currentTime - (lastPressTime.current[key.name] || 0) < 300) {
            newActiveKeys[key.name] = true;
        }
    });

    setActiveKeys(newActiveKeys);
  });

  return (
    <group position={[0, -2, 0]} rotation={[-0.2, 0, 0]}>
      {NOTES.map((note) => (
        <Key 
          key={note.name} 
          {...note} 
          isPressed={!!activeKeys[note.name]} 
        />
      ))}
      <mesh position={[0, -0.5, 0]}>
        <boxGeometry args={[20, 0.5, 5]} />
        <meshStandardMaterial color="#050505" roughness={0.2} metalness={0.8} />
      </mesh>
    </group>
  );
};