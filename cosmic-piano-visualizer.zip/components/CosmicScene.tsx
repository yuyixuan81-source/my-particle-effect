import React, { useState, useEffect, Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, Stars, Sparkles } from '@react-three/drei';
import { EffectComposer, Bloom } from '@react-three/postprocessing';
import { Piano } from './Piano';
import { MathShape } from './MathShape';
import { ParticleShape } from '../types';

interface CosmicSceneProps {
  handPositions: { x: number; y: number }[];
  currentShape: ParticleShape;
}

const SceneContent: React.FC<CosmicSceneProps> = ({ handPositions, currentShape }) => {
    const [beatPulse, setBeatPulse] = useState(0);

    const handleNotePress = (note: string) => {
        setBeatPulse(1);
    };

    // Decay beat pulse
    useEffect(() => {
        if (beatPulse > 0) {
            const timer = requestAnimationFrame(() => {
                setBeatPulse(prev => Math.max(0, prev - 0.1));
            });
            return () => cancelAnimationFrame(timer);
        }
    }, [beatPulse]);

    return (
        <>
            <ambientLight intensity={0.2} />
            <pointLight position={[10, 10, 10]} intensity={1} />
            <color attach="background" args={['#000000']} />
            
            {/* Background Atmosphere */}
            <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade speed={1} />
            <Sparkles count={500} scale={20} size={2} speed={0.4} opacity={0.5} color="#44aaff" />
            
            <Piano handPositions={handPositions} onKeyPress={handleNotePress} />
            
            {/* The Mathematical Shape Visualizer on the right */}
            <MathShape currentShape={currentShape} beatPulse={beatPulse} />

            <OrbitControls 
                enableZoom={false} 
                enablePan={false}
                minPolarAngle={Math.PI / 4} 
                maxPolarAngle={Math.PI / 2}
            />

            <EffectComposer disableNormalPass>
                <Bloom luminanceThreshold={0} mipmapBlur intensity={1.5} radius={0.6} />
            </EffectComposer>
        </>
    );
};

export const CosmicScene: React.FC<CosmicSceneProps> = (props) => {
  return (
    <Canvas camera={{ position: [0, 2, 8], fov: 60 }}>
      <Suspense fallback={null}>
         <SceneContent {...props} />
      </Suspense>
    </Canvas>
  );
};