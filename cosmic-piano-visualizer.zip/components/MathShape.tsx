import React, { useMemo, useRef, useEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { ParticleShape } from '../types';
import { audioService } from '../services/audioService';

interface MathShapeProps {
  currentShape: ParticleShape;
  beatPulse: number;
}

const HEAD_COUNT = 1000;
const TRAIL_LENGTH = 12;
const TOTAL_PARTICLES = HEAD_COUNT * TRAIL_LENGTH;
const DECAY_RATE = 0.85;

export const MathShape: React.FC<MathShapeProps> = ({ currentShape, beatPulse }) => {
  const pointsRef = useRef<THREE.Points>(null);
  
  // Buffers
  const particles = useMemo(() => {
    // These buffers will be used for the geometry attributes
    const positions = new Float32Array(TOTAL_PARTICLES * 3);
    const colors = new Float32Array(TOTAL_PARTICLES * 3);

    // These store the target state for the HEAD particles only
    const targetPositions = new Float32Array(HEAD_COUNT * 3);
    const baseHsl = new Float32Array(HEAD_COUNT * 3);
    
    // Initial random positions
    for(let i=0; i<HEAD_COUNT; i++) {
        const x = (Math.random() - 0.5) * 10;
        const y = (Math.random() - 0.5) * 10;
        const z = (Math.random() - 0.5) * 10;
        
        // Fill all trail segments for this head
        for (let t = 0; t < TRAIL_LENGTH; t++) {
            const idx = (i * TRAIL_LENGTH + t) * 3;
            positions[idx] = x;
            positions[idx+1] = y;
            positions[idx+2] = z;
            
            // Initial white
            colors[idx] = 1; colors[idx+1] = 1; colors[idx+2] = 1;
        }
    }

    return { positions, colors, baseHsl, targetPositions };
  }, []);

  // Update Target Positions based on Shape (Only for Heads)
  useEffect(() => {
    const { targetPositions, baseHsl } = particles;
    let i3 = 0;
    const tempColor = new THREE.Color();
    const tempHsl = { h: 0, s: 0, l: 0 };
    
    for (let i = 0; i < HEAD_COUNT; i++) {
      const t = i / HEAD_COUNT;
      let x = 0, y = 0, z = 0;
      
      // Determine Position and Base Color
      switch (currentShape) {
        case ParticleShape.LORENZ:
          let lx = 0.1, ly = 0, lz = 0;
          const dt = 0.01;
          const sigma = 10, rho = 28, beta = 8/3;
          // Re-simulate locally for deterministic position based on index (simulated)
          lx = Math.sin(i * 0.1) * 2;
          ly = Math.cos(i * 0.1) * 2;
          lz = 20 + Math.sin(i * 0.05) * 10;
          
          for(let s=0; s<20; s++) { // Short simulation steps
             let dx = sigma * (ly - lx) * dt;
             let dy = (lx * (rho - lz) - ly) * dt;
             let dz = (lx * ly - beta * lz) * dt;
             lx += dx; ly += dy; lz += dz;
          }
          x = lx * 0.15;
          y = ly * 0.15;
          z = (lz - 25) * 0.15;
          tempColor.setHSL(0.1 + (lz/50)*0.2, 0.8, 0.5);
          break;

        case ParticleShape.MOBIUS:
           const u = (t * 4 * Math.PI); 
           const v = (Math.sin(i * 0.1)) * 0.5; 
           x = (1 + v/2 * Math.cos(u/2)) * Math.cos(u) * 2;
           y = (1 + v/2 * Math.cos(u/2)) * Math.sin(u) * 2;
           z = v/2 * Math.sin(u/2) * 2;
           tempColor.setHSL(u / (4*Math.PI), 0.7, 0.5);
           break;

        case ParticleShape.SPHERE:
           const theta = Math.random() * Math.PI * 2;
           const phi = Math.acos(Math.random() * 2 - 1);
           const r = 2.5;
           x = r * Math.sin(phi) * Math.cos(theta);
           y = r * Math.sin(phi) * Math.sin(theta);
           z = r * Math.cos(phi);
           tempColor.setHSL(0.6, 0.8, 0.6);
           break;
        
        case ParticleShape.GALAXY:
            const angle = t * Math.PI * 2 * 5; 
            const radius = (i / HEAD_COUNT) * 3 + 0.5;
            const spiralOffset = radius * 2;
            x = Math.cos(angle + spiralOffset) * radius;
            z = Math.sin(angle + spiralOffset) * radius;
            y = (Math.random() - 0.5) * (1 / (radius + 0.1));
            tempColor.setHSL(0.6 + radius/6, 0.8, 0.6);
            break;

        case ParticleShape.HEART:
            const ht = (t * Math.PI * 2);
            const h_angle = Math.random() * Math.PI * 2;
            x = 16 * Math.pow(Math.sin(h_angle), 3);
            y = 13 * Math.cos(h_angle) - 5 * Math.cos(2*h_angle) - 2 * Math.cos(3*h_angle) - Math.cos(4*h_angle);
            z = (Math.random() - 0.5) * 4;
            x *= 0.15; y *= 0.15; z *= 0.15;
            tempColor.setHSL(0.95, 0.8, 0.4);
            break;

        default: 
           x = (Math.random() - 0.5) * 4;
           y = (Math.random() - 0.5) * 4;
           z = (Math.random() - 0.5) * 4;
           tempColor.setHSL(Math.random(), 0.5, 0.5);
      }

      targetPositions[i3] = x;
      targetPositions[i3+1] = y;
      targetPositions[i3+2] = z;
      
      tempColor.getHSL(tempHsl);
      baseHsl[i3] = tempHsl.h;
      baseHsl[i3+1] = tempHsl.s;
      baseHsl[i3+2] = tempHsl.l;

      i3 += 3;
    }
    
  }, [currentShape, particles]);

  useFrame((state) => {
    if (!pointsRef.current) return;
    
    const positions = pointsRef.current.geometry.attributes.position.array as Float32Array;
    const colors = pointsRef.current.geometry.attributes.color.array as Float32Array;
    const { targetPositions, baseHsl } = particles;
    
    // Get Audio Data
    const freqData = audioService.getFrequencyData();
    const tempColor = new THREE.Color();
    const lerpFactor = 0.1;

    // Iterate over each HEAD
    for (let i = 0; i < HEAD_COUNT; i++) {
        const headIdx = i * TRAIL_LENGTH; // Index in the full buffer (stride TRAIL_LENGTH)
        const headIdx3 = headIdx * 3; // Index in the float32 array
        
        // 1. Shift Trail (Backwards iteration to carry values)
        for (let t = TRAIL_LENGTH - 1; t > 0; t--) {
            const currentIdx3 = (headIdx + t) * 3;
            const prevIdx3 = (headIdx + t - 1) * 3;

            // Shift Position
            positions[currentIdx3] = positions[prevIdx3];
            positions[currentIdx3+1] = positions[prevIdx3+1];
            positions[currentIdx3+2] = positions[prevIdx3+2];

            // Shift and Decay Color
            colors[currentIdx3] = colors[prevIdx3] * DECAY_RATE;
            colors[currentIdx3+1] = colors[prevIdx3+1] * DECAY_RATE;
            colors[currentIdx3+2] = colors[prevIdx3+2] * DECAY_RATE;
        }

        // 2. Update Head
        const targetIdx3 = i * 3; // Index in target array
        
        // Move towards target
        positions[headIdx3] += (targetPositions[targetIdx3] - positions[headIdx3]) * lerpFactor;
        positions[headIdx3+1] += (targetPositions[targetIdx3+1] - positions[headIdx3+1]) * lerpFactor;
        positions[headIdx3+2] += (targetPositions[targetIdx3+2] - positions[headIdx3+2]) * lerpFactor;

        // Color based on Audio
        if (freqData) {
            const freqIndex = i % freqData.length;
            const intensity = freqData[freqIndex] / 255;
            
            let h = baseHsl[targetIdx3];
            let s = baseHsl[targetIdx3+1];
            let l = baseHsl[targetIdx3+2];

            h = (h + intensity * 0.1) % 1; 
            l = Math.min(1, l + intensity * 0.8); 
            
            tempColor.setHSL(h, s, l);
            
            colors[headIdx3] = tempColor.r;
            colors[headIdx3+1] = tempColor.g;
            colors[headIdx3+2] = tempColor.b;
        } else {
             // Fallback color if no audio yet
             let h = baseHsl[targetIdx3];
             let s = baseHsl[targetIdx3+1];
             let l = baseHsl[targetIdx3+2];
             tempColor.setHSL(h, s, l);
             colors[headIdx3] = tempColor.r;
             colors[headIdx3+1] = tempColor.g;
             colors[headIdx3+2] = tempColor.b;
        }
    }
    
    // Beat pulse effect (scale)
    const scale = 1 + beatPulse * 0.2;
    pointsRef.current.scale.setScalar(scale);
    
    // Slow rotation
    pointsRef.current.rotation.y += 0.002;
    pointsRef.current.rotation.z += 0.001;
    
    pointsRef.current.geometry.attributes.position.needsUpdate = true;
    pointsRef.current.geometry.attributes.color.needsUpdate = true;
  });

  return (
    <group position={[4, 1, 0]}>
      <points ref={pointsRef}>
        <bufferGeometry>
          <bufferAttribute
            attach="attributes-position"
            count={TOTAL_PARTICLES}
            array={particles.positions}
            itemSize={3}
          />
          <bufferAttribute
            attach="attributes-color"
            count={TOTAL_PARTICLES}
            array={particles.colors}
            itemSize={3}
          />
        </bufferGeometry>
        <pointsMaterial
          size={0.05}
          vertexColors
          transparent
          opacity={0.8}
          blending={THREE.AdditiveBlending}
          sizeAttenuation={true}
          depthWrite={false}
        />
      </points>
    </group>
  );
};