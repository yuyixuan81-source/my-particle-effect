import React, { useEffect, useRef, useState } from 'react';
import { FilesetResolver, HandLandmarker } from '@mediapipe/tasks-vision';
import { NOTES, PIANO_WIDTH } from './Piano';

interface HandTrackerProps {
  onHandsDetected: (positions: { x: number; y: number }[]) => void;
}

export const HandTracker: React.FC<HandTrackerProps> = ({ onHandsDetected }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [permissionGranted, setPermissionGranted] = useState(false);
  const lastVideoTimeRef = useRef(-1);
  const handLandmarkerRef = useRef<HandLandmarker | null>(null);

  useEffect(() => {
    const initMediaPipe = async () => {
      const vision = await FilesetResolver.forVisionTasks(
        "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.0/wasm"
      );
      handLandmarkerRef.current = await HandLandmarker.createFromOptions(vision, {
        baseOptions: {
          modelAssetPath: `https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task`,
          delegate: "GPU"
        },
        runningMode: "VIDEO",
        numHands: 2
      });
    };

    initMediaPipe();

    const getCamera = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.addEventListener("loadeddata", predictWebcam);
          setPermissionGranted(true);
        }
      } catch (err) {
        console.error("Camera denied:", err);
      }
    };

    getCamera();

    return () => {
        // Cleanup logic if needed
    }
  }, []);

  const drawExoskeleton = (ctx: CanvasRenderingContext2D, landmarks: any[]) => {
    // MediaPipe Hand Connections
    const connections = [
        [0, 1], [1, 2], [2, 3], [3, 4], // Thumb
        [0, 5], [5, 6], [6, 7], [7, 8], // Index
        [5, 9], [9, 10], [10, 11], [11, 12], // Middle
        [9, 13], [13, 14], [14, 15], [15, 16], // Ring
        [13, 17], [17, 18], [18, 19], [19, 20], // Pinky
        [0, 17], [5, 9], [9, 13], [13, 17] // Palm
    ];

    const { width, height } = ctx.canvas;

    // Draw Glow
    ctx.shadowBlur = 15;
    ctx.shadowColor = '#00ffff';

    // Draw Connections
    ctx.strokeStyle = 'rgba(0, 255, 255, 0.8)';
    ctx.lineWidth = 2;
    ctx.lineCap = 'round';
    
    connections.forEach(([start, end]) => {
        const p1 = landmarks[start];
        const p2 = landmarks[end];
        ctx.beginPath();
        ctx.moveTo(p1.x * width, p1.y * height);
        ctx.lineTo(p2.x * width, p2.y * height);
        ctx.stroke();
    });

    // Draw Joints
    landmarks.forEach((p: any, index: number) => {
        ctx.beginPath();
        // Fingertips (4, 8, 12, 16, 20) get larger, brighter dots
        const isTip = [4, 8, 12, 16, 20].includes(index);
        const radius = isTip ? 4 : 2;
        ctx.fillStyle = isTip ? '#ffffff' : '#00aaaa';
        
        ctx.arc(p.x * width, p.y * height, radius, 0, 2 * Math.PI);
        ctx.fill();
    });
  };

  const predictWebcam = async () => {
    if (videoRef.current && handLandmarkerRef.current) {
      const nowInMs = Date.now();
      if (videoRef.current.currentTime !== lastVideoTimeRef.current) {
        lastVideoTimeRef.current = videoRef.current.currentTime;
        const startTimeMs = performance.now();
        const results = handLandmarkerRef.current.detectForVideo(videoRef.current, startTimeMs);

        // Canvas Drawing Logic
        if (canvasRef.current && videoRef.current) {
            const canvas = canvasRef.current;
            const ctx = canvas.getContext('2d');
            
            // Sync canvas size with video resolution
            if (canvas.width !== videoRef.current.videoWidth || canvas.height !== videoRef.current.videoHeight) {
                canvas.width = videoRef.current.videoWidth;
                canvas.height = videoRef.current.videoHeight;
            }

            if (ctx) {
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                if (results.landmarks) {
                    for (const landmarks of results.landmarks) {
                        drawExoskeleton(ctx, landmarks);
                    }
                }
            }
        }

        if (results.landmarks) {
          const tips: {x: number, y: number}[] = [];
          for (const landmarks of results.landmarks) {
             // Index finger tip is landmark 8
             const indexTip = landmarks[8];
             // Mirror X for intuitive interaction
             tips.push({ x: 1 - indexTip.x, y: indexTip.y });
          }
          onHandsDetected(tips);
        }
      }
      requestAnimationFrame(predictWebcam);
    }
  };

  // Calculate dynamic boundaries for the overlay based on actual note positions
  const minX = NOTES[0]?.x || 0;
  const maxX = NOTES[NOTES.length - 1]?.x || 0;
  
  // Map world X to percentage of interaction space (0..1)
  const getPct = (worldX: number) => ((worldX / PIANO_WIDTH) + 0.5) * 100;

  const startPct = getPct(minX) - 2; // Add a little padding
  const endPct = getPct(maxX) + 2;

  return (
    <div className="absolute bottom-4 left-4 border-2 border-cyan-500 rounded-lg overflow-hidden w-64 h-48 z-50 bg-black shadow-[0_0_15px_rgba(6,182,212,0.5)]">
       <div className="relative w-full h-full">
           <video 
             ref={videoRef} 
             autoPlay 
             playsInline
             muted
             className="absolute inset-0 w-full h-full object-cover transform -scale-x-100" 
           />
           
           {/* Exoskeleton Canvas Overlay */}
           <canvas
             ref={canvasRef}
             className="absolute inset-0 w-full h-full object-cover transform -scale-x-100 pointer-events-none"
           />

           {/* Piano Zones Overlay */}
           {permissionGranted && (
               <div className="absolute inset-0 pointer-events-none opacity-60">
                   {/* Background Gradient for Active Area */}
                   <div 
                     className="absolute bottom-0 top-0 bg-cyan-900/20 border-x border-cyan-500/30"
                     style={{
                         left: `${startPct}%`, 
                         right: `${100 - endPct}%`
                     }}
                   >
                     <div className="absolute top-2 w-full text-center text-[10px] text-cyan-300 font-mono tracking-widest opacity-80">PIANO ZONE</div>
                   </div>

                   {/* Individual Keys */}
                   {NOTES.map(note => {
                       const leftPct = getPct(note.x);
                       const isWhite = note.type === 'white';
                       const heightClass = isWhite ? 'h-8' : 'h-5';
                       const colorClass = isWhite ? 'bg-cyan-400/30' : 'bg-cyan-200/50';
                       const width = isWhite ? 'w-px' : 'w-1';
                       
                       // Only draw lines for white keys or specific markers to avoid clutter
                       if (!isWhite) return null;

                       return (
                           <div 
                             key={note.name}
                             className={`absolute bottom-0 ${heightClass} ${width} ${colorClass}`}
                             style={{ left: `${leftPct}%` }}
                           >
                              {/* Only label C keys */}
                              {note.name.startsWith('C') && !note.name.includes('#') && (
                                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 text-[6px] text-white">
                                      {note.name}
                                  </div>
                              )}
                           </div>
                       );
                   })}
               </div>
           )}

           {!permissionGranted && (
               <div className="absolute inset-0 flex items-center justify-center text-xs text-cyan-300 text-center p-2 bg-black/80">
                   Waiting for Camera...
               </div>
           )}
       </div>
    </div>
  );
};