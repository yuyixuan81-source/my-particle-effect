import React, { useState, useEffect } from 'react';
import { CosmicScene } from './components/CosmicScene';
import { HandTracker } from './components/HandTracker';
import { ParticleShape, GeminiResponse } from './types';
import { getShapeInsight } from './services/geminiService';
import { audioService } from './services/audioService';

const SHAPES = Object.values(ParticleShape);

const App: React.FC = () => {
  const [handPositions, setHandPositions] = useState<{ x: number; y: number }[]>([]);
  const [currentShape, setCurrentShape] = useState<ParticleShape>(ParticleShape.GALAXY);
  const [started, setStarted] = useState(false);
  const [insight, setInsight] = useState<GeminiResponse | null>(null);
  const [loadingInsight, setLoadingInsight] = useState(false);

  // Cycle shapes automatically or manually
  // Let's add UI controls for shapes
  
  const handleStart = async () => {
    audioService.initialize();
    setStarted(true);
    await fetchInsight(currentShape);
  };

  const handleShapeChange = async (shape: ParticleShape) => {
      setCurrentShape(shape);
      await fetchInsight(shape);
  };

  const fetchInsight = async (shape: ParticleShape) => {
      setLoadingInsight(true);
      const data = await getShapeInsight(shape);
      if (data) {
          setInsight(data);
      }
      setLoadingInsight(false);
  };

  return (
    <div className="w-full h-screen bg-black relative text-white">
      {/* 3D Scene Layer */}
      <div className="absolute inset-0 z-0">
        <CosmicScene handPositions={handPositions} currentShape={currentShape} />
      </div>

      {/* UI Overlay Layer */}
      <div className="absolute inset-0 z-10 pointer-events-none">
        {/* Header */}
        <div className="w-full p-6 flex justify-between items-start bg-gradient-to-b from-black/80 to-transparent">
          <div>
            <h1 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-500 tracking-widest drop-shadow-[0_0_10px_rgba(0,255,255,0.5)]">
              COSMIC RESONANCE
            </h1>
            <p className="text-cyan-200/60 text-sm mt-1">Gestural Music Visualization Interface</p>
          </div>
          
          {/* Gemini Insight Panel */}
          <div className="w-80 bg-black/40 backdrop-blur-md border border-purple-500/30 p-4 rounded-xl pointer-events-auto transition-all hover:bg-black/60">
             <h3 className="text-purple-300 font-bold mb-2 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-purple-500 animate-pulse"></span>
                AI ANALYST (GEMINI)
             </h3>
             {loadingInsight ? (
                 <div className="text-xs text-gray-400 animate-pulse">Analyzing cosmic geometry...</div>
             ) : insight ? (
                 <div className="space-y-2">
                     <p className="text-sm text-gray-200 italic">"{insight.description}"</p>
                     <div className="h-px w-full bg-purple-500/30"></div>
                     <p className="text-xs text-cyan-300 font-mono">MATH_FACT: {insight.scientificFact}</p>
                 </div>
             ) : (
                 <div className="text-xs text-gray-500">System Standby</div>
             )}
          </div>
        </div>

        {/* Right Side Shape Controls */}
        <div className="absolute right-6 top-1/2 transform -translate-y-1/2 flex flex-col gap-2 pointer-events-auto">
             {SHAPES.map(shape => (
                 <button 
                    key={shape}
                    onClick={() => handleShapeChange(shape)}
                    className={`px-4 py-2 text-xs font-mono border-r-4 transition-all text-right
                        ${currentShape === shape 
                            ? 'border-cyan-500 bg-cyan-900/30 text-cyan-100 shadow-[0_0_15px_rgba(6,182,212,0.4)]' 
                            : 'border-transparent text-gray-500 hover:text-gray-300 hover:bg-white/5'
                        }
                    `}
                 >
                    {shape}
                 </button>
             ))}
        </div>
      </div>

      {/* Hand Tracker Feed (Bottom Left) */}
      {started && (
        <div className="pointer-events-auto">
             <HandTracker onHandsDetected={setHandPositions} />
        </div>
      )}

      {/* Start Screen Modal */}
      {!started && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-sm">
          <div className="max-w-md text-center space-y-8 p-8 border border-cyan-500/30 rounded-2xl bg-black/50 shadow-[0_0_50px_rgba(8,145,178,0.2)]">
             <div className="space-y-4">
                <h2 className="text-4xl text-white font-bold tracking-tighter">INITIATE SEQUENCE</h2>
                <p className="text-gray-400 text-sm">
                    Allow camera access to enable gesture control. <br/>
                    Use your index finger to strike the virtual keys.
                </p>
             </div>
             <button 
                onClick={handleStart}
                className="px-8 py-3 bg-cyan-600 hover:bg-cyan-500 text-white font-bold rounded-none border border-cyan-300 transition-all hover:shadow-[0_0_20px_rgba(6,182,212,0.6)] tracking-widest"
             >
                ENTER THE VOID
             </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;