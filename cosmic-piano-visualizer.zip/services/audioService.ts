class AudioService {
  private audioContext: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private analyser: AnalyserNode | null = null;
  private dataArray: Uint8Array | null = null;

  initialize() {
    if (!this.audioContext) {
      this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      this.masterGain = this.audioContext.createGain();
      this.masterGain.gain.value = 0.5;

      this.analyser = this.audioContext.createAnalyser();
      this.analyser.fftSize = 256;
      this.analyser.smoothingTimeConstant = 0.8;
      this.dataArray = new Uint8Array(this.analyser.frequencyBinCount);

      this.masterGain.connect(this.analyser);
      this.analyser.connect(this.audioContext.destination);
    }
  }

  playNote(frequency: number) {
    if (!this.audioContext || !this.masterGain) return;

    if (this.audioContext.state === 'suspended') {
      this.audioContext.resume();
    }

    const oscillator = this.audioContext.createOscillator();
    const gainNode = this.audioContext.createGain();

    oscillator.type = 'sine'; // Sine wave for a pure tone, close to a simple electric piano
    oscillator.frequency.setValueAtTime(frequency, this.audioContext.currentTime);

    // Envelope for a plucked/struck sound
    gainNode.gain.setValueAtTime(0, this.audioContext.currentTime);
    gainNode.gain.linearRampToValueAtTime(1, this.audioContext.currentTime + 0.02);
    gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + 1.5);

    oscillator.connect(gainNode);
    gainNode.connect(this.masterGain);

    oscillator.start();
    oscillator.stop(this.audioContext.currentTime + 1.5);
    
    // Add harmonics for a richer sound
    this.addHarmonic(frequency * 2, 0.3);
    this.addHarmonic(frequency * 3, 0.1);
  }

  private addHarmonic(freq: number, gain: number) {
    if (!this.audioContext || !this.masterGain) return;
    const osc = this.audioContext.createOscillator();
    const g = this.audioContext.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(freq, this.audioContext.currentTime);
    g.gain.setValueAtTime(0, this.audioContext.currentTime);
    g.gain.linearRampToValueAtTime(gain, this.audioContext.currentTime + 0.02);
    g.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + 1.0);
    osc.connect(g);
    g.connect(this.masterGain);
    osc.start();
    osc.stop(this.audioContext.currentTime + 1.0);
  }

  getFrequencyData(): Uint8Array | null {
    if (this.analyser && this.dataArray) {
      this.analyser.getByteFrequencyData(this.dataArray);
      return this.dataArray;
    }
    return null;
  }
}

export const audioService = new AudioService();