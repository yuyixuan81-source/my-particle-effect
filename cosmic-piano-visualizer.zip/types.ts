export enum ParticleShape {
  SPHERE = 'SPHERE',
  CUBE = 'CUBE',
  LORENZ = 'LORENZ',
  MOBIUS = 'MOBIUS',
  MENGER = 'MENGER',
  GALAXY = 'GALAXY',
  HEART = 'HEART',
  PENROSE = 'PENROSE'
}

export interface KeyState {
  note: string;
  isPressed: boolean;
  color: string;
}

export interface HandLandmark {
  x: number;
  y: number;
  z: number;
}

export interface GeminiResponse {
  description: string;
  scientificFact: string;
}
